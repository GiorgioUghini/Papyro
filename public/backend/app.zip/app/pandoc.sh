#!/usr/bin/env bash
pandoc -s --toc -c /backend/main.css  markdown/D1.md -o public/backend/main.html